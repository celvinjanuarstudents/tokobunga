<?php
include 'header.php';

$invoices = $_GET['inv'];
$d_order = mysqli_query($conn, "SELECT * FROM produksi WHERE invoice = '$invoices'");
$t_order = mysqli_fetch_assoc($d_order);

// customer
$cs = mysqli_query($conn, "SELECT * FROM customer WHERE kode_customer = '".$t_order['kode_customer']."'");
$t_cs = mysqli_fetch_assoc($cs);
?>

<div class="container">
    <h2 style=" width: 100%; border-bottom: 4px solid gray"><b>Detail Pesanan</b></h2>
    <br>

    <div class="row">
        <div class="col-md-6">
            <h4>Informasi Pesanan</h4>
            <table class="table table-bordered">
                <tr>
                    <td>Invoice</td>
                    <td><?= $t_order['invoice']; ?></td>
                </tr>
                <tr>
                    <td>Kode Customer</td>
                    <td><?= $t_order['kode_customer']; ?></td>
                </tr>
                <tr>
                    <td>Nama Customer</td>
                    <td><?= $t_cs['nama']; ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td>
                        <?= $t_order['provinsi'] ; ?>
                        <br>
                        <?= $t_order['kota'] ; ?>
                        <br>
                        <?= $t_order['alamat'] ; ?>
                        <br>
                        <?= $t_order['kode_pos'] ; ?>
                    </td>
                </tr>
                <tr>
                    <td>No Telp</td>
                    <td><?= $t_cs['telp']; ?></td>
                </tr>
                
                
            </table>
        </div>

        <div class="col-md-6">
            <h4>Detail Produk</h4>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Produk</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $order = mysqli_query($conn, "SELECT * FROM produksi WHERE invoice = '$invoices'");
                    $no = 1;
                    $grand = 0;

                    while ($list = mysqli_fetch_assoc($order)) {
                    ?>
                        <tr>
                            <td><?= $no; ?></td>
                            <td><?= $list['kode_produk']; ?></td>
                            <td><?= $list['nama_produk']; ?></td>
                            <td><?= number_format($list['harga'], 0, ".", "."); ?></td>
                            <td><?= $list['qty']; ?></td>
                            <td><?= number_format($list['harga'] * $list['qty'], 0, ".", "."); ?></td>
                        </tr>
                    <?php
                        $sub = $list['harga'] * $list['qty'];
                        $grand += $sub;
                        $no++;
                    }
                    ?>
                    <tr>
                        <td colspan="5" class="text-right"><b>Grand Total</b></td>
                        <td><?= number_format($grand, 0, ".", "."); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
