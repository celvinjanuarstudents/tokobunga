<?php 
include '../../koneksi/koneksi.php';

$inv = $_GET['inv'];

// Mengambil data produksi berdasarkan nomor invoice
$result = mysqli_query($conn, "SELECT * FROM produksi WHERE invoice = '$inv'");

if ($result) {
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        // Mendapatkan nilai-nilai yang diperlukan dari hasil produksi
        $kodebk = $row['kode_bahan'];
        $hasil = $row['hasil'];

        // Periksa apakah tabel 'inventory' ada
        $checkTable = mysqli_query($conn, "SHOW TABLES LIKE 'inventory'");
        if (mysqli_num_rows($checkTable) > 0) {
            // Update jumlah stok di tabel inventory
            $updateInventory = mysqli_query($conn, "UPDATE inventory SET qty = qty - '$hasil' WHERE kode_bahan = '$kodebk'");

            if ($updateInventory) {
                // Mengubah status produksi menjadi 'Diterima'
                mysqli_query($conn, "UPDATE produksi SET terima = '1', status = '0' WHERE invoice = '$inv'");

                echo "
                <script>
                alert('PESANAN BERHASIL DITERIMA');
                window.location = '../produksi.php';
                </script>
                ";
            } 
        } 
    } 
} 

?>
