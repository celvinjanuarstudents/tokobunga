<?php
include 'header.php';

// Menghitung jumlah produksi yang mengalami kekurangan material
$sortage = mysqli_query($conn, "SELECT * FROM produksi where cek = '1'");
$cek_sor = mysqli_num_rows($sortage);

?>

<div class="container">
    <h2 style="width: 100%; border-bottom: 4px solid gray;"><b>Daftar Pesanan</b></h2>
    <br>
    <h5 class="bg-success" style="padding: 7px; width: 710px; font-weight: bold;">
        <marquee>Lakukan Reload Setiap Masuk Halaman ini, untuk menghindari terjadinya kesalahan data dan informasi</marquee>
    </h5>
    <a href="produksi.php" class="btn btn-default">
        <i class="glyphicon glyphicon-refresh"></i> Reload
    </a>
    <br>

    <table class="table table-striped">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Invoice</th>
                <th scope="col">Kode Customer</th>
                <th scope="col">Status</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php 
            // Query untuk mendapatkan data produksi
            $result = mysqli_query($conn, "SELECT DISTINCT invoice, kode_customer, status, kode_produk, qty, terima, tolak, cek, tanggal FROM produksi group by invoice");
            $no = 1;
            $nama_material = []; // Inisialisasi array untuk menyimpan nama material yang kurang
            while ($row = mysqli_fetch_assoc($result)) {
                $kodep = $row['kode_produk'];
                $inv = $row['invoice'];
            ?>

                <tr>
                    <td><?= $no; ?></td>
                    <td><?= $row['invoice']; ?></td>
                    <td><?= $row['kode_customer']; ?></td>
                    
                    <?php 
                    // Menentukan status pesanan
                    if ($row['terima'] == 1) {
                        echo '<td style="color: green; font-weight: bold;">Pesanan Diterima (Siap Kirim)</td>';
                    } elseif ($row['tolak'] == 1) {
                        echo '<td style="color: red; font-weight: bold;">Pesanan Ditolak</td>';
                    } else {
                        echo '<td style="color: orange; font-weight: bold;">' . $row['status'] . '</td>';
                    }


                    // Menampilkan tanggal pesanan
                    echo '<td>' . $row['tanggal'] . '</td>';
                    ?>

                    <td>
                        <?php 
                        if ($row['tolak'] == 0 && $row['cek'] == 1 && $row['terima'] == 0) {
                            // Tombol untuk Request Material Shortage dan Tolak
                            echo '<a href="inventory.php?cek=0" id="rq" class="btn btn-warning"><i class="glyphicon glyphicon-warning-sign"></i> Request Material Shortage</a>';
                            echo '<a href="proses/tolak.php?inv=' . $row['invoice'] . '" class="btn btn-danger" onclick="return confirm(\'Yakin Ingin Menolak ?\')"><i class="glyphicon glyphicon-remove-sign"></i> Tolak</a>';
                        } elseif ($row['terima'] == 0 && $row['cek'] == 0) {
                            // Tombol untuk Terima dan Tolak
                            echo '<a href="proses/terima.php?inv=' . $row['invoice'] . '&kdp=' . $row['kode_produk'] . '" class="btn btn-success"><i class="glyphicon glyphicon-ok-sign"></i> Terima</a>';
                            echo '<a href="proses/tolak.php?inv=' . $row['invoice'] . '" class="btn btn-danger" onclick="return confirm(\'Yakin Ingin Menolak ?\')"><i class="glyphicon glyphicon-remove-sign"></i> Tolak</a>';
                        }
                        
                        // Tombol untuk Detail Pesanan
                        echo '<a href="detailorder.php?inv=' . $row['invoice'] . '&cs=' . $row['kode_customer'] . '" type="submit" class="btn btn-primary"><i class="glyphicon glyphicon-eye-open"></i> Detail Pesanan</a>';
                        
                        // Tombol untuk Terima
                            echo '<a href="proses/terima.php?inv=' . $row['invoice'] . '&kdp=' . $row['kode_produk'] . '" class="btn btn-success"><i class="glyphicon glyphicon-ok-sign"></i> Terima</a>';
                        
                            // Tombol untuk Tolak
                            echo '<a href="proses/tolak.php?inv=' . $row['invoice'] . '" class="btn btn-danger" onclick="return confirm(\'Yakin Ingin Menolak ?\')"><i class="glyphicon glyphicon-remove-sign"></i> Tolak</a>';
                        ?>

                        
                    </td>
                </tr>

            <?php
                $no++;
            }
            ?>

        </tbody>
    </table>

    <?php 
    if ($cek_sor > 0) {
    ?>
        <br>
        <br>
        
    <?php 
    }
    ?>

</div>

<br>
<br>
<br>

<?php 
include 'footer.php';
?>
