<?php
include 'header.php';
?>

<!-- SEARCH FORM -->
<div class="container">
    <form class="form-inline" method="GET" action="search.php">
        <div class="form-group">
            <label for="search">Cari Produk:</label>
            <input type="text" class="form-control" id="search" name="query" placeholder="Masukkan nama produk">
        </div>
        <button type="submit" class="btn btn-primary">Cari</button>
    </form>
</div>

<div class="container">
    <h2><b>Produk Kami</b></h2>

    <div class="row">
        <?php
        if (isset($_GET['query'])) {
            $search_query = $_GET['query'];
            $result = mysqli_query($conn, "SELECT * FROM produk WHERE nama LIKE '%$search_query%'");
        } else {
            $result = mysqli_query($conn, "SELECT * FROM produk");
        }

        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <div class="col-sm-6 col-md-4">
                <div class="thumbnail">
                    <img src="image/produk/<?= $row['image']; ?>" >
                    <div class="caption">
                        <h3><?= $row['nama'];  ?></h3>
                        <h4>Rp.<?= number_format($row['harga']); ?></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <a href="detail_produk.php?produk=<?= $row['kode_produk']; ?>" class="btn btn-warning btn-block">Detail</a> 
                            </div>
                            <?php if(isset($_SESSION['kd_cs'])){ ?>
                                <div class="col-md-6">
                                    <a href="proses/add.php?produk=<?= $row['kode_produk']; ?>&kd_cs=<?= $kode_cs; ?>&hal=1" class="btn btn-success btn-block" role="button"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                                </div>
                                <?php 
                            }
                            else{
                                ?>
                                <div class="col-md-6">
                                    <a href="keranjang.php" class="btn btn-success btn-block" role="button"><i class="glyphicon glyphicon-shopping-cart"></i> Tambah</a>
                                </div>
                                <?php 
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php 
        }
        ?>
    </div>
</div>

<?php
include 'footer.php';
?>
