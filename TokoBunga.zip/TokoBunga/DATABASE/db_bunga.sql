-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2023 at 11:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bunga`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$AIy0X1Ep6alaHDTofiChGeqq7k/d1Kc8vKQf1JZo0mKrzkkj6M626');

-- --------------------------------------------------------

--
-- Table structure for table `bom_produk`
--

CREATE TABLE `bom_produk` (
  `kode_bom` varchar(100) NOT NULL,
  `kode_bahan` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `kebutuhan` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `kode_customer` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `telp` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`kode_customer`, `nama`, `email`, `username`, `password`, `telp`) VALUES
('C0002', 'Rafi Akbar', 'a.rafy@gmail.com', 'rafi', '$2y$10$/UjGYbisTPJhr8MgmT37qOXo1o/HJn3dhafPoSYbOlSN1E7olHIb.', '0856748564'),
('C0003', 'Nagita Silvana', 'bambang@gmail.com', 'Nagita', '$2y$10$47./qEeA/y3rNx3UkoKmkuxoAtmz4ebHSR0t0Bc.cFEEg7cK34M3C', '087804616097'),
('C0004', 'Nadiya', 'nadiya@gmail.com', 'nadiya', '$2y$10$6wHH.7rF1q3JtzKgAhNFy.4URchgJC8R.POT1osTAWmasDXTTO7ZG', '0898765432'),
('C0005', 'putri', 'selaraskasi@gmail.com', 'putriwu', '$2y$10$bHK1qXnw1jNT.5hwQ5Lxk.fVHDZkalLa2AK.3P9d/9EJc.Gqu8oLy', '082165886599'),
('C0006', 'panisia', 'panisiaanggi@gmail.com', 'panisia', '$2y$10$LUUrz6HhnzLnxOxsc1dgL.iJwIW9lGHEmhSoosmW9tVszj.9A87eq', '082269804077'),
('C0007', 'Arini', 'arini@gmail.com', 'Arini', '$2y$10$fn1sqmhUEpQ2weQxNkN53ea4.ETLk9l.bxg27LE.cJnvepscgAsSO', '082346781298');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `kode_bahan` varchar(100) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `qty` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `kode_customer` varchar(100) NOT NULL,
  `kode_produk` varchar(100) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id_keranjang`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`) VALUES
(16, 'C0003', 'P0002', 'Maryam', 5, 15000),
(17, 'C0003', 'P0003', 'Kue tart coklat', 2, 100000),
(45, 'C0005', 'P0001', 'Lily Crown Flower', 1, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `kode_produk` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `image` text NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`kode_produk`, `nama`, `image`, `deskripsi`, `harga`) VALUES
('P0001', 'Lily Crown Flower', '65521e822465b.jpeg', '																								Design dengan mahkota bunga yang menyerupai mahkota kerajaan.\r\n																																																																		', 50000),
('P0002', 'Daisy Crown Flower', '655226332dc46.jpg', '				Design yang simple dan elegan cocok untuk berpergian santai \r\n												', 80000),
('P0003', 'Rose Crown Flower', '655227f8bd262.jpg', '											Menggunakan	duplikat bunga mawar dan dipadu dengan bunga babys breathe.', 100000),
('P0004', 'Bouquet Babys Breath', '655228f2814b4.jpg', '\r\n			', 100000),
('P0005', 'Bouquet Red Rose', '656ae515682eb.jpg', '\r\n			indah', 130000);

-- --------------------------------------------------------

--
-- Table structure for table `produksi`
--

CREATE TABLE `produksi` (
  `id_order` int(11) NOT NULL,
  `invoice` varchar(200) NOT NULL,
  `kode_customer` varchar(200) NOT NULL,
  `kode_produk` varchar(200) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `status` varchar(200) NOT NULL,
  `tanggal` date NOT NULL,
  `provinsi` varchar(200) NOT NULL,
  `kota` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kode_pos` varchar(200) NOT NULL,
  `terima` varchar(200) NOT NULL,
  `cek` int(11) NOT NULL,
  `Bank` varchar(20) NOT NULL,
  `tolak` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produksi`
--

INSERT INTO `produksi` (`id_order`, `invoice`, `kode_customer`, `kode_produk`, `nama_produk`, `qty`, `harga`, `status`, `tanggal`, `provinsi`, `kota`, `alamat`, `kode_pos`, `terima`, `cek`, `Bank`, `tolak`) VALUES
(15, 'INV0006', 'C0005', 'P0002', 'Daisy Crown Flower', 1, 80000, '1', '2323-11-16', 'Medann', 'Medann', 'Tembung', '23456', '1', 0, '', ''),
(16, 'INV0007', 'C0005', 'P0002', 'Daisy Crown Flower', 1, 80000, '0', '2323-11-16', 'pakam', 'pakam', 'pakam', '24567', '1', 0, '', ''),
(17, 'INV0008', 'C0006', 'P0003', 'Rose Crown Flower', 1, 100000, '0', '2323-11-16', 'Medann', 'Medann', 'Tembung', '23456', '1', 0, '', ''),
(19, 'INV0010', 'C0006', 'P0001', 'Lily Crown Flower', 1, 50000, '0', '2323-11-16', 'Medann', 'pakam', 'pakam', '22067', '1', 0, '', ''),
(20, 'INV0011', 'C0006', 'P0004', 'Bouquet Babys Breath', 1, 100000, '0', '2323-11-16', 'Sumatera Utara', 'Medann', 'Tembung', '23456', '1', 0, '', ''),
(26, 'INV0012', 'C0005', 'P0001', 'Lily Crown Flower', 1, 50000, '0', '2323-11-21', 'Sumatera Utara', 'Siantar', 'Siantar', '2151', '1', 0, '', ''),
(30, 'INV0013', 'C0005', 'P0001', 'Lily Crown Flower', 1, 50000, '0', '2323-11-27', 'Sumatera Utara', 'Pematangsiantar', 'Jl.Nusa Indah', '22151', '1', 0, '', ''),
(31, 'INV0014', 'C0005', 'P0001', 'Lily Crown Flower', 1, 50000, '0', '2323-11-27', 'Sumatera Utara', 'Pematangsiantar', 'Jl.Nusa Indah', '22151', '2', 0, '', '1'),
(32, 'INV0015', 'C0005', 'P0001', 'Lily Crown Flower', 2, 50000, '0', '2323-12-02', 'sumut', 'deli-serdang', 'pakam', '24567', '1', 0, '', ''),
(33, 'INV0016', 'C0005', 'P0001', 'Lily Crown Flower', 1, 50000, 'Pesanan Baru', '2323-12-02', 'Sumatera Utara', 'medan', 'Siantar', '21151', '2', 0, '', '1'),
(34, 'INV0017', 'C0005', 'P0001', 'Lily Crown Flower', 1, 50000, 'Pesanan Baru', '2323-12-08', 'Sumatera Utara', 'Medan', 'Tembung', '23456', '', 0, '', ''),
(35, 'INV0018', 'C0005', 'P0001', 'Lily Crown Flower', 1, 50000, 'Pesanan Baru', '2323-12-11', 'Sumatera Utara', 'Medan', 'Tembung', '23456', '', 0, '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`kode_customer`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`kode_produk`);

--
-- Indexes for table `produksi`
--
ALTER TABLE `produksi`
  ADD PRIMARY KEY (`id_order`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `produksi`
--
ALTER TABLE `produksi`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
