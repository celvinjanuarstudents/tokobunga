<?php 
include 'header.php';
$kd = mysqli_real_escape_string($conn, $_GET['kode_cs']);
$cs = mysqli_query($conn, "SELECT * FROM customer WHERE kode_customer = '$kd'");
$rows = mysqli_fetch_assoc($cs);
?>

<div class="container" style="padding-bottom: 200px">
    <h2 style="width: 100%; border-bottom: 4px solid #ff8680"><b>Checkout</b></h2>
    <div class="row">
        <div class="col-md-6">
            <h4>Daftar Pesanan</h4>
            <table class="table table-stripped">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Qty</th>
                    <th>Sub Total</th>
                </tr>
                <?php 
                $result = mysqli_query($conn, "SELECT * FROM keranjang WHERE kode_customer = '$kd'");
                $no = 1;
                $hasil = 0;
                while($row = mysqli_fetch_assoc($result)){
                    ?>
                    <tr>
                        <td><?= $no; ?></td>
                        <td><?= $row['nama_produk']; ?></td>
                        <td>Rp.<?= number_format($row['harga']); ?></td>
                        <td><?= $row['qty']; ?></td>
                        <td>Rp.<?= number_format($row['harga'] * $row['qty']);  ?></td>
                    </tr>
                    <?php 
                    $total = $row['harga'] * $row['qty'];
                    $hasil += $total;
                    $no++;
                }
                ?>
                <tr>
                    <td colspan="5" style="text-align: right; font-weight: bold;">Grand Total = Rp.<?= number_format($hasil); ?></td>
                </tr>
            </table>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6 bg-success">
            <h5>Pastikan Pesanan Anda Sudah Benar</h5>
        </div>
    </div>

    <br>

    <div class="row">
        <div class="col-md-6 bg-warning">
            <h5>Isi Formulir di Bawah Ini</h5>
        </div>
    </div>

    <br>

    <form action="proses/order.php" method="POST">
        <input type="hidden" name="kode_cs" value="<?= $kd; ?>">
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" placeholder="Nama" name="nama" style="width: 557px;" value="<?= $rows['nama']; ?>" readonly>
        </div>

        <div class="row">
            <div class="col-md-6">
            <div class="form-group">
                    <label for="prov">Provinsi</label>
                    <select class="form-control" id="prov" name="prov">
                        <option value="Sumatera Utara">Sumatera Utara</option>
                        <!-- Tambahkan opsi untuk provinsi lain jika diperlukan -->
                    </select>
                </div>

            </div>

            <div class="col-md-6">
            <div class="form-group">
                <label for="kota">Kota</label>
                <select class="form-control" id="kota" name="kota">
                    <option value="Medan">Medan</option>
                    <option value="Binjai">Binjai</option>
                    <option value="Deli-Serdang">Deli Serdang</option>
                    <!-- Tambahkan opsi untuk kota lain di Sumatera Utara jika diperlukan -->
                </select>
            </div>

            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="almt">Alamat</label>
                    <input type="text" class="form-control" id="almt" placeholder="Alamat" name="almt">
                </div>
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <label for="kopos">Kode Pos</label>
                    <input type="text" class="form-control" id="kopos" placeholder="Kode Pos" name="kopos">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <p>Silahkan Transfer Melalui Bank BCA dengan a.n Putri Wulandari nomor <b>12981491</b></p>
                </div>
            </div>
        </div>
        
       
        <div>
            <p>
            <span>Konfirmasi Pembayaran melalui nomor berikut :  <a href="https://wa.me/+6282370593451">Putri Wulandari</a></span>
            </p>
        
        </div>
        <button type="submit" class="btn btn-success"><i class="glyphicon glyphicon-shopping-cart"></i> Order Sekarang</button>
        <a href="keranjang.php" class="btn btn-danger">Cancel</a>
    </form>
</div>

<?php include 'footer.php'; ?>
