
	<footer style="border-top: 4px solid #ff8680;  ">
		<div class="container" style="padding-bottom: 50px;">
			<div class="row">
				<div class="col-md-4">
					<h3 style="color: #ff8680"><b>FLORIST HOUSE</b></h3>
					<p>Jl.Gambir Pasar VIII</p>
					<p><i class="glyphicon glyphicon-earphone"></i> +6282370593451</p>
					<p><i class="glyphicon glyphicon-envelope"></i> floristhouse@gmail.com</p>
				</div>
				<div class="col-md-4">
					<h5><b>Menu</b></h5>
					<p><a href=""  style="color: #000">Produk</a></p>
					<p><a href=""  style="color: #000">Tentang kami</a></p>
					<p><a href=""  style="color: #000">Hubungi Kami</a></p>
				</div>

				<div class="col-md-4">
					
				</div>
			</div>

		</div>

		<div class="copy" style="background-color: #ff8680; padding: 5px; color: #fff; text-align: center;">
			<span>Copyright&copy; Putri Wulandari Hasibuan</span>
		</div>
	</footer>

</body>
</html>