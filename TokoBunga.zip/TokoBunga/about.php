<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #ff8680"><b>Tentang Kami</b></h2>
	<p class="text-justify">Florist House adalah toko bunga online terlengkap dan terpercaya, dengan harga terjangkau anda sudah dapat memiliki produk kami. Selamat Berbelanja Customer..</p>
</div>




 <?php 
	include 'footer.php';
 ?>